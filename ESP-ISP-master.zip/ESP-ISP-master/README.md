# ESP-ISP
ESP32 based ISP programmer for Atmel 8051 with a web and app GUI

ESP_ISP Contains Code For ESP32 for Arduino IDE (Use ESP32 sketch data uploader to upload html files to ESP32)


python_gui Contains python script for Application GUI (Use requirements.txt for required Python packages)

TODO
-------
Documentation
